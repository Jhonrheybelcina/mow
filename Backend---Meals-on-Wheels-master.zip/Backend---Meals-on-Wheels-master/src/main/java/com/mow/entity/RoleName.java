package com.mow.entity;

public enum RoleName {

	ROLE_ADMINISTRATOR,
	ROLE_MEMBER,
	ROLE_PARTNER,
	ROLE_RIDER,
	ROLE_DONOR
}