package com.mow.entity;

import javax.persistence.*;

@Entity
@Table(name = "Preparation")
public class Preparation {
	
    @Id
    @Column(name = "prep_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long prepId;

    @ManyToOne
    @JoinColumn(name = "id")
    private User partner;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private OrderRequest order;

//    @OneToOne
//    @JoinColumn(name = "member_id")
//    private OrderRequest member;
    
    @Column(name = "member_id")
    private Long memberId;

    @Column(name = "prep_status")
    private String prepStatus;

    
    
    
	public Preparation() {

	}

	public Preparation(Long prepId, User partner, OrderRequest order, Long memberId, String prepStatus) {
		super();
		this.prepId = prepId;
		this.partner = partner;
		this.order = order;
		this.memberId = memberId;
		this.prepStatus = prepStatus;
	}

	public Long getPrepId() {
		return prepId;
	}

	public void setPrepId(Long prepId) {
		this.prepId = prepId;
	}

	public User getPartner() {
		return partner;
	}

	public void setPartner(User partner) {
		this.partner = partner;
	}

	public OrderRequest getOrder() {
		return order;
	}

	public void setOrder(OrderRequest order) {
		this.order = order;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getPrepStatus() {
		return prepStatus;
	}

	public void setPrepStatus(String prepStatus) {
		this.prepStatus = prepStatus;
	}

    
    
}
