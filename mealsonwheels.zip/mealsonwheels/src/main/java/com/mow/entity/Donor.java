package com.mow.entity;

import javax.persistence.*;

@Entity
@Table(name = "donors")
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long donorId;

    private String donorName;
    private String donated;
    private Long roleId;
    private String dateDonated;
    public Donor() {
    }

    public Donor(String donorName, String donated, Long roleId, String dateDonated) {
        this.donorName = donorName;
        this.donated = donated;
        this.roleId = roleId;
        this.dateDonated = dateDonated;
    }

  

    @Override
	public String toString() {
		return "Donor [donorId=" + donorId + ", donorName=" + donorName + ", donated=" + donated + ", roleId=" + roleId
				+ ", dateDonated=" + dateDonated + "]";
	}

	public Long getDonorId() {
        return donorId;
    }

    public void setDonorId(Long donorId) {
        this.donorId = donorId;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public String getDonated() {
        return donated;
    }

    public void setDonated(String donated) {
        this.donated = donated;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

	public String getDateDonated() {
		return dateDonated;
	}

	public void setDateDonated(String dateDonated) {
		this.dateDonated = dateDonated;
	}
    
}
