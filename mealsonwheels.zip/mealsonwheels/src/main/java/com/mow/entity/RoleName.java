package com.mow.entity;

public enum RoleName {

	ADMINISTRATOR,
	MEMBER,
	PARTNER,
	RIDER,
	DONOR
}